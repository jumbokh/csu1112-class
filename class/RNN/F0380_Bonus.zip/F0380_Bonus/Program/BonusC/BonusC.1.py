# %% 載入 IMDB 資料集並進行序列對齊和資料切割
from tensorflow.keras.datasets import imdb
from tensorflow.keras.preprocessing.sequence import pad_sequences

num_words = 10000    #←只處理常見的前 10000 個單字

(train_data, train_labels), (test_data, test_labels) = imdb.load_data(num_words= num_words) 

maxlen = 500    #←設定序列長度為 500

train_data = pad_sequences(train_data, maxlen=maxlen, truncating='post')    #←只取前 500 個單字, 超過的截掉

val_data = train_data[-5000:]    #←取後 5000 筆資料用作驗證資料, 與validation_split設定為0.2是一樣的意思
train_data = train_data[:-5000]    #←取前 20000 筆資料用作訓練資料

val_labels = train_labels[-5000:]
train_labels = train_labels[:-5000]

# %% 將資料轉成 one-hot 編碼生成器
import utilC as u

batch_size = 50   #←設定generator的批次量大小為50

train_data_oh = u.seq2oh_generator(train_data,train_labels,batch_size=batch_size,num_classes=num_words)
val_data_oh = u.seq2oh_generator(val_data,val_labels,batch_size=batch_size,num_classes=num_words)

# %% 建立oh-LSTM模型
from tensorflow.keras.models import Sequential
from tensorflow.keras import layers

model = Sequential()
model.add(layers.InputLayer(input_shape=(maxlen, num_words)))
model.add(layers.LSTM(20))
model.add(layers.Dense(1, activation='sigmoid'))
model.summary()

# %% 訓練模型
model.compile(optimizer='rmsprop',
              loss='binary_crossentropy',
              metrics=['acc'])

history = model.fit(train_data_oh,
                    steps_per_epoch=len(train_data)//batch_size,
                    validation_data=val_data_oh,
                    validation_steps=len(val_data)//batch_size,
                    epochs=10,
                    verbose=1)

# %%
u.plot(history.history,
       ['loss','val_loss'],
       title='Training & Validation Loss',
       xyLabel=['Epoch','Loss'])

u.plot(history.history,
       ['acc','val_acc'],
       title='Training & Validation Acc',
       xyLabel=['Epoch','Acc'])