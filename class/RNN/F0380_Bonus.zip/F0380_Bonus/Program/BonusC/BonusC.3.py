#%% 載入 IMDB 資料集並進行資料處理
from tensorflow.keras.datasets import imdb
from tensorflow.keras.preprocessing.sequence import pad_sequences

num_words = 10000    #←只處理常見的前 10000 個單字

(train_data, train_labels), (test_data, test_labels) = imdb.load_data(num_words= num_words) 

val_data = train_data[-5000:]    #←取後5000筆資料用作驗證資料, 與validation_split設定為0.2是一樣的意思
train_data = train_data[:-5000]    #←取前20000(25000-5000)筆資料用作訓練資料

val_labels = train_labels[-5000:]
train_labels = train_labels[:-5000]

import utilC as u

n_train_data,index,num_words = u.n_gram(train_data,n=2,num_words=num_words)
n_val_data,_,num_words = u.n_gram(val_data,n=2,num_words=num_words,index=index,append=False)

maxlen = 1000
n_train_data = pad_sequences(n_train_data, maxlen=maxlen,truncating='post')
n_val_data = pad_sequences(n_val_data, maxlen=maxlen,truncating='post')

# %% 建立模型並訓練
from tensorflow.keras.models import Sequential
from tensorflow.keras import layers

model = Sequential()
model.add(layers.Embedding(num_words, 24, input_length=maxlen))
model.add(layers.LSTM(20))
model.add(layers.Dense(1, activation='sigmoid'))
model.summary()

model.compile(optimizer='rmsprop',
              loss='binary_crossentropy',
              metrics=['acc'])

history = model.fit(n_train_data, train_labels,
                    epochs=10,
                    batch_size=128,
                    validation_data=(n_val_data,val_labels)
                    )

# %%
u.plot(history.history,
       ['loss','val_loss'],
       title='Training & Validation Loss',
       xyLabel=['Epoch','Loss'])

u.plot(history.history,
       ['acc','val_acc'],
       title='Training & Validation Acc',
       xyLabel=['Epoch','Acc'])