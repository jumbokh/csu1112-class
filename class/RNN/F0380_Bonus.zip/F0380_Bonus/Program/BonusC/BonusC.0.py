#%% 資料處理
from tensorflow.keras.datasets import imdb
from tensorflow.keras.preprocessing.sequence import pad_sequences

(train_data, train_labels),(test_data, test_labels) = imdb.load_data(num_words=10000)

maxlen = 500
train_data = pad_sequences(train_data, maxlen=maxlen, truncating='post')
test_data = pad_sequences(test_data, maxlen=maxlen, truncating='post')

import utilC as u

train_data_seq = u.seq_for_rnn(train_data)
print(train_data_seq.shape)
#%% 建立模型並訓練
from tensorflow.keras.models import Sequential
from tensorflow.keras import layers

model = Sequential()
model.add(layers.LSTM(20,input_shape=(maxlen,1)))
model.add(layers.Dense(1, activation='sigmoid'))
model.summary()

model.compile(optimizer='rmsprop',
              loss='binary_crossentropy',
              metrics=['acc'])

history = model.fit(train_data_seq, train_labels,
                    epochs=10,
                    batch_size=512,
                    validation_split=0.2)

# %%
u.plot(history.history,
       ['loss','val_loss'],
       title='Training & Validation Loss',
       xyLabel=['Epoch','Loss'])

u.plot(history.history,
       ['acc','val_acc'],
       title='Training & Validation Acc',
       xyLabel=['Epoch','Acc'])

# %%
