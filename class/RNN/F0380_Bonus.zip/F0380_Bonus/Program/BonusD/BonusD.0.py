# %% 下載公開 (騰訊) 預訓練詞向量 
from tensorflow.keras.utils import get_file
import os

path = os.getcwd()+os.sep+'Tencent_AILab_ChineseEmbedding.tar.gz'
origin = 'https://ai.tencent.com/ailab/nlp/data/Tencent_AILab_ChineseEmbedding.tar.gz'
cache_dir = os.getcwd()+os.sep+'cache'

path = get_file(path,
                origin,
                cache_dir=cache_dir,
                extract=True
                )

# %% 讀取部分的詞向量檔案
wv_path = 'cache/datasets/Tencent_AILab_ChineseEmbedding.txt'
with open(wv_path,encoding='utf-8-sig') as file:
    for _ in range(5):    #←讀取前 5 行
        print(file.readline())


# %%
