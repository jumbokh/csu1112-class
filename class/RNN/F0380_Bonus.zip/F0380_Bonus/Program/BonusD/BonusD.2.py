# %% -------------  調整區   ------------- # 

maxlen = 100            # 只看資料的最後 maxlen 個字
train_num = 4000        # 每個話題的數量 (不可取超過 4000 筆)
epochs = 20             # 訓練週期
batch_size = 128        # 批次量
max_words = 20000       # 詞彙量

topics = ['音乐', '政治', '游戏', '电影', '法律',       # 使用簡體字
          '情感', '健康', '教育', '美食', '旅行']

# %% ---------------- 載入資料集 ---------------- #

# 將資料依據話題種類存入
topic_contents = {'电影': [], '法律': [], '游戏': [], '音乐': [], '政治': [], 
                    '情感': [], '健康': [], '教育': [], '美食': [], '旅行': [],}

# 載入資料集
from tensorflow.keras.preprocessing.text import Tokenizer

tokenizer = Tokenizer(num_words=max_words, oov_token='N')

with open("simp_dataSet.txt", 'r', encoding='utf-8-sig') as file:
    word_seq = []
    num_texts = 0
    for data in file:
        topic, content = data.split('@@')   # 用 @@ 將資料切開
        content = content.strip()           # 去除前後的換行字元與空白
        topic_contents[topic].append(content)    # 依據話題分類儲存
        word_seq.append(content)
        num_texts += 1
        if num_texts%1000 == 0:
            tokenizer.fit_on_texts(word_seq)
            print('\r已處理',num_texts,'個句子',end='')
            word_seq = []
    if word_seq:
        tokenizer.fit_on_texts(word_seq)
        print('\r已處理',num_texts,'個句子',end='')
        del word_seq
    print('\nToken建立完畢')

# %% ---- 將字詞轉成索引數字, 並只取最後 100 個, 多切少補 0 ---- #
from tensorflow.keras.preprocessing.sequence import pad_sequences

for topic, contents in topic_contents.items():
    seqs = tokenizer.texts_to_sequences(contents)      # 轉換
    seqs = pad_sequences(seqs, maxlen=maxlen)       # 使用回應資料的最後面 20 個字, 多切少補
    topic_contents[topic] = seqs

# %% -------- 設定神經網路要進行幾種話題的分類 -------- #

# 產生話題的數字標籤
topic_label = {}
for label, topic in enumerate(topics):
    topic_label[topic] = label

# %% -------- 建立訓練、驗證資料與標籤 -------- #

import numpy as np

valid_num = 1000    # 每個話題取 最後 1000 筆做為驗證資料

# 先製作空的 array, 其 shape 為 (訓練樣本數, 詞彙數), 這是為了要存放後面的 array 資料
train_data = np.empty((train_num * len(topics), maxlen))
valid_data = np.empty((valid_num * len(topics),maxlen))
train_labels = []       # 存放訓練資料標籤
valid_labels = []       # 存放驗證資料標籤

for i, topic in enumerate(topics):
    # 分配訓練資料
    start = i * train_num
    end = start + train_num
    train_data[start: end] = topic_contents[topic][: train_num]
    # 分配驗證資料
    start = i * valid_num
    end = start + valid_num
    valid_data[start: end] = topic_contents[topic][-valid_num: ]

    label = topic_label[topic]  # 取出話題所對應的數字標籤
    train_labels.extend( [label] * train_num)   # 建立訓練標籤資料
    valid_labels.extend( [label] * valid_num)   # 建立驗證標籤資料

# 將標籤 list 轉成 張量
train_labels = np.asarray(train_labels)
valid_labels = np.asarray(valid_labels)

# %% -------- 打亂資料順序 -------- #
indices_train = np.arange(train_data.shape[0])  # 產生 0~199 的數字, 這是訓練資料的索引位置
np.random.shuffle(indices_train)                # 打亂索引位置
train_data = train_data[indices_train]          # 根據新的索引位置對原始訓練資料、標籤進行排列
train_labels = train_labels[indices_train]

indices_valid = np.arange(valid_data.shape[0])  # 產生 0~1999 的數字, 這是驗證資料的索引位置
np.random.shuffle(indices_valid)                # 打亂索引位置
valid_data = valid_data[indices_valid]          # 根據新的索引位置對原始驗證資料、標籤進行排列
valid_labels = valid_labels[indices_valid]

# %% ---- 載入公開的預訓練詞向量 ---- #
wv_path = 'cache/datasets/Tencent_AILab_ChineseEmbedding.txt'
with open(wv_path, encoding='utf-8-sig') as file:

    head = file.readline().strip().split()   #←取出第一行, 即詞向量檔案的資訊
    total_words = int(head[0])
    embedding_dim = int(head[1])

    print('總共有',total_words,'個詞, 詞向量維度為',embedding_dim)

    # 先製作空的詞嵌入層權重 array, 其 shape 為 (詞彙數, 詞向量維度)
    embedding_matrix = np.empty((max_words, embedding_dim))
    match_num = 0   #←用來記錄吻合的詞彙量
    pg_percent = 0   #←用來記錄進度比例

    for i,line in enumerate(file):
        values = line.split()
        word = values[0]
        num = tokenizer.word_index.get(word)   #←將詞轉數字
        if num is not None and num<max_words:   #←判斷詞是否有在詞彙對照表中, 並在前20000個常用詞中
            try:
                vector = np.asarray(values[1:], dtype='float32')   #←取出詞的向量 (200 個數字)
                embedding_matrix[num] = vector   #←將向量存入權重矩陣中
                match_num+=1
            except:
                print('\n格式錯誤:',line)
        if i>=(total_words/100)*pg_percent:
            pg_percent+=1
            print('\r已處理 %i%s 的詞' % (pg_percent,'%'),end='')
    print('\r已處理 100% 的詞')

print('吻合的詞向量數量:', match_num)

# %% 建立神經網路

from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, Flatten, Dense, LSTM, Dropout, Conv1D, MaxPooling1D

model = Sequential()

model.add(Embedding(max_words, 100, 
                    input_length=maxlen, 
                    name='word2vec'))
model.add(Dropout(0.25))
model.add(Conv1D(filters=256,
                    kernel_size=5,
                    padding='valid',
                    activation='relu',
                    strides=1))
model.add(MaxPooling1D(pool_size=2))
model.add(LSTM(256, dropout=0.2, recurrent_dropout=0.2))
model.add(Dense(256, activation='relu'))
model.add(Dropout(0.5))
model.add(Dense(len(topics), activation='softmax'))

model.layers[0].set_weights([embedding_matrix])   #←載入剛剛建立的權重矩陣
model.layers[0].trainable = False   #←凍結詞嵌入層

model.summary()

# %% 訓練神經網路

model.compile(optimizer='adam',
            loss='sparse_categorical_crossentropy',
            metrics=['acc'])
history = model.fit(train_data,
                    train_labels,
                    epochs=epochs,
                    batch_size=batch_size,
                    validation_data=(valid_data, valid_labels),
                    )

# %%
import util6 as u    	# 匯入自訂的繪圖工具模組

u.plot( history.history,   # 繪製準確率與驗證準確度的歷史線圖
        ('acc', 'val_acc'),
        'Training & Vaildation Acc',
        ('Epoch','Acc'), 
        )