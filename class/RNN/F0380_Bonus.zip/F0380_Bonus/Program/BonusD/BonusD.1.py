# %% 將簡體資料集轉為繁體
from opencc import OpenCC

f = open('dataSet.txt', encoding='utf-8-sig')
new_f = open('simp_dataSet.txt',mode = 'w', encoding='utf-8-sig')

cc_t2s = OpenCC('t2s')
for i,line in enumerate(f):
    print('\r已處理',i,'個句子',end='')
    new_f.writelines(cc_t2s.convert(line))

f.close()
new_f.close()
print('轉換完成')