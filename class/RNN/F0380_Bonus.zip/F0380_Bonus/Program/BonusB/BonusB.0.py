import numpy as np

a = np.arange(1, 13).reshape((2,2,3)) # a 為 (2, 2, 3) 的陣列
b = np.arange(1, 25).reshape((2,3,4)) # b 為 (2, 3, 4) 的陣列

a2 = np.reshape(a, (4, 3))            # 將 a reshape 為 2D 的 (4, 3)
b2 = np.moveaxis(b, -2, 0)            # 將 b 的 -2 軸先移到第 0 軸
b2 = np.reshape(b2, (3, 8))           #   再 reshape 為 2D 的 (3, 8)

x = np.dot(a2,  b2)                   # 將 a2 和 b2 做點積
y = np.reshape(x, (2, 2, 2, 4))       # 再將結果 reshape 回原來應有的形狀

print(f'\na  的 shape：{a.shape}\n{a}')             #}顯示各變數的形將與內容
print(f'\nb  的 shape：{b.shape}\n{b}')             #}
print(f'\na2 的 shape：{a2.shape}\n{a2}')           #}
print(f'\nb2 的 shape：{b2.shape}\n{b2}')           #}
print(f'\ndot(a2 ,b2) 的 shape：{x.shape}\n{x}')    #}
print(f'\nreshape 回原來應有的形狀：{y.shape}\n{y}') #}

z = np.dot(a, b)    # 驗證 dot(a2, b2) 的結果是否和 dot(a, b) 相同
print('\ndot(a,b) 和 dot(a2,b2) 的差異：', np.sum(y != z))