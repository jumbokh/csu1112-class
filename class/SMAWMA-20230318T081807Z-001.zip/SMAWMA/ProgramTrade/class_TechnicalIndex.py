# -*- coding: utf-8 -*-
"""
Created on Wed Jul 26 10:41:42 2017

@author: 蔡金進, 林萍珍
"""
import pandas as pd
import numpy as np

class TechicalIndex():
    def __init__(self,Data):
        self.open=Data[['open']]
        self.hjgh=Data[['high']]
        self.low=Data[['low']]
        self.close=Data[['close']]
 #定義 MA 方法    
    def MA(self, n):
       colname = 'MA' + str(n)
       mav=self.close.rolling(window=n).mean()
       mav.columns=[colname]
       return mav 
#定義 RSI 方法  
    def RSI(self, n):
       (r,c)=self.close.shape
       colname = 'RSI' + str(n)   
       close=self.close.diff()                 
       rsiv=pd.DataFrame(columns=[colname],index=[close.index])   
       pup, pdown, au, ad, rs = np.zeros(r), np.zeros(r), np.zeros(r),\
          np.zeros(r), np.zeros(r)

       for i in range(1,r):
         if float(close.iloc[i]) > 0.00000:
             pup[i] = float(close.iloc[i])
             pdown[i] = 0
         else:
             pdown[i] = -1 * float(close.iloc[i])
             pup[i] = 0
       au[n-1]=pup[0:n].mean()
       ad[n-1]=pdown[0:n].mean()
       for i in range(n,r):
           au[i]=au[i-1] + (pup[i] -au[i-1])/n
           ad[i]=ad[i-1] + (pdown[i] -ad[i-1])/n
           rs[i]=au[i]/ad[i]
           rsiv.iloc[i]=100 - (100/(1+rs[i]))        
       return rsiv