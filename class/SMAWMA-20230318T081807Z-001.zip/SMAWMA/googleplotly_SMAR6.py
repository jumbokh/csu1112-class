# -*- coding: utf-8 -*-
"""
Created on Thu Jun 22 09:11:04 2017
1. 自Google finance抓取台股日資料(任意期間)
2. 繪製OHLC股票圖(K線)
3. 技術指標
4. 存入EXCEL檔案
@author: 蔡金進, 林萍珍
"""
import pandas as pd
import numpy as np
import datetime
import time

#引入自建類別ProgramTrade class_GetGoogleFinance
import ProgramTrade.class_GetGoogleFinance as Gf
#引用talib相關套件
import talib
#引用plotly相關套件
import plotly
from plotly.graph_objs import Figure
import plotly.offline as pyo
#設定plotly帳號與apikey
plotly.tools.set_credentials_file(username='danny1053422', api_key='GubB4ZT48GrLd3Z8HB8C')
pyo.offline.init_notebook_mode()

#繪製K線圖
def showMAplot(df):
 
    #設定X,Y軸以及格式化線圖
    trace1 = {'type':'scatter',
            'x' : df['dates'],
            'y' : df['close'],
            'name':'收盤價',
            'mode':'lines'}
    trace2 = {'type':'scatter',
            'x' : df['dates'],
            'y' : df['SMA'],
            'name':'SMA',
            'mode':'lines'}
    trace3 = {'type':'scatter',
            'x' : df['dates'],
            'y' : df['WMA'],
            'name':'WMA',            
            'mode':'lines'}
    trace4 = {'type':'scatter',
            'x' : df['XBuy'],
            'y' : df['YBuy'],
            'name':'買進點',            
            'mode': 'markers',      
            'marker':dict(           
            size = 10,
            color='red' )}       
                       
    trace5 = {'type':'scatter',
            'x' : df['XSell'],
            'y' : df['YSell'],
            'name':'賣出點',            
            'mode': 'markers',
            'marker':dict(           
            symbol='diamond',    
            size = 10,    
            color='black')}    
                        
    layout = {'title':'簡單移動平均(SMA)與加權移動平均(WMA)交叉',
             'xaxis':{'title':'日期'},
             'yaxis':{'title':'價格'}, 
             }

    data = [trace1, trace2, trace3, trace4, trace5]
    fig = Figure(data=data, layout=layout)
    pyo.plot(fig)  

def SMAWMA(df, count, acmroi, winrate, winfact):
    close = np.array(df['close'], dtype=float)
    SMA = talib.SMA(close,5) #close 代進SMA方法做計算
    WMA = talib.WMA(close,5) #close 代進WMA方法做計算
    df['SMA'] = SMA
    df['WMA'] = WMA
    print(df)
    #設定初始值
    df['XBuy'] = np.nan
    df['YBuy'] = np.nan
    df['XSell'] = np.nan
    df['YSell'] = np.nan
#-----------------------------
    row = len(df)
    flag = False
    change = 0
    buyprice=[]
    sellprice=[]
    win = 0
    loss = 0
    roi = 0
    for i in range(row):
        change = df['WMA'].iloc[i]/ df['SMA'].iloc[i]
        if (flag == False) & (df['WMA'].iloc[i] > df['SMA'].iloc[i]) & (change >= 1.02):
            print(i)
            print('漲跌幅 = ',  change*100)
            print('Buy')
            print(df.close[i])
            df['XBuy'].iloc[i] =  df['dates'].iloc[i]
            df['YBuy'].iloc[i] = df['close'].iloc[i]
            buyprice = df['close'].iloc[i]
            flag = True
        if (flag == True) & (df['WMA'].iloc[i] <= df['SMA'].iloc[i]) & (change <= 0.98):
            print(i)
            print('漲跌幅 = ',  change*100)     
            print('Sell')
            print(df['close'].iloc[i])
            df.XSell[i] = df['dates'].iloc[i]
            df.YSell[i] = df['close'].iloc[i]
            sellprice = df['close'].iloc[i]
            count += 1
            flag = False 
            [roi, winrate] = roical(buyprice, sellprice, winrate)
            acmroi += roi
            [loss, win] = winfactor(buyprice, sellprice, loss, win)
        if (flag == True & i==(row-1)):
            df.XSell[i] = df['dates'].iloc[i]
            df.YSell[i] = df['close'].iloc[i]
            sellprice = df['close'].iloc[i]
            count += 1
            [roi, winrate] = roical(buyprice, sellprice, winrate)
            acmroi += roi
    if loss == 0:
        loss = win
    winvar = win / loss
    return (df, count, acmroi, winrate, winvar) 

#計算報酬率與勝率
def roical(buyprice, sellprice, winrate):
    roi = ((sellprice - buyprice) / buyprice)
    if roi > 0:
        winrate+=1
    return (roi, winrate)

#計算獲利因子要用的累計獲利金額與損失金額
def winfactor(buyprice, sellprice, loss, win):
    payoff = buyprice - sellprice
    if payoff > 0:
        loss += payoff
    else:
        win += (-payoff)
    return (loss, win)
    
#主程式
def main(stkno,start,end): 
    #產生GetGoogleFinance類別的物件實體(gf)
    gf=Gf.GetGoogleFinance(stkno,start,end,False)   #此處修改
    #取出物gf物件實體的資料指派給Data
    RowData =gf.getstock(True)
    #將股價資料轉成dataframe
    df = pd.DataFrame(RowData)
    #初始值設定
    str1 = ''
    count = 0
    acmroi = 0 
    winrate = 0
    winfact = 0
    #呼叫SMAWMA策略

    [df, count, acmroi, winrate, winfact] = SMAWMA(df, count, acmroi, winrate, winfact)
    str1 = '交易次數 = '+ str(count) + ' 次; ' + '累計報酬率 = ' + str(round(acmroi*100, 2)) + '%; .' + '勝率 = ' + str(winrate) + '; 獲利因子 = ' + str(winfact) 
    print(str1)          
    
    #將呼叫畫圖函數showMAplot
    showMAplot(df)
   
    #呼叫存入excel檔的方法
    gf.savetoexcel(df,stkno)    #Save data to excel
#    showcandle(Data)
#呼叫主程式並代入股票代號與起訖日期
if __name__ == "__main__":   
    starttime = time.clock()
    stkno='2421'
    start = datetime.datetime(2007,10,1)
    end = datetime.datetime(2017,9,30)
    df = main(stkno,start,end)
    endtime = time.clock()
    print('程式執行時間 = %d%s' %(round(endtime-starttime), '秒'))