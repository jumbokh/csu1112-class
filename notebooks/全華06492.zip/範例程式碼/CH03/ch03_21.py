import numpy as np

a = np.array([-1.3,  1.5,  -2.7,  0.6,  2.3])
print ('輸入的數值陣列值：')
print (a)
print ('向上取整後的值：')
print (np.ceil(a))

