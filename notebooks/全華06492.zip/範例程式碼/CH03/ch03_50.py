import pandas as pd
# 建立Pandas Series物件
data = pd.Series(["Jacky","Peter","Many","Joe"],
                  index = ["n1","n2","n3","n4",])
print(data.size)

