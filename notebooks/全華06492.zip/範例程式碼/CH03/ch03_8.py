import numpy as np
# 資料型態默認為浮點數
a1 = np.ones(6)
print(a1)
# 資料型設定為整數
a2 = np.ones([3, 2], dtype=int)
print(a2)

