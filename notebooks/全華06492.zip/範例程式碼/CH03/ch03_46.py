import pandas as pd

dic_data ={'name':'Jacky','Degree':'Phd','sex':'Male '}
myData = pd.Series(dic_data)
print(myData)
print("myData['name'] :",myData['name'])



