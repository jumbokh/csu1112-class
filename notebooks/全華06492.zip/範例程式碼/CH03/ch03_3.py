import numpy as np

x1 = np.arange(5)
print (x1)
print(x1.dtype)
x2 = np.arange(0,5,dtype = np.float32)
print (x2)
print (x2.dtype)
x3 = np.arange(0,10,2,dtype = np.float64)
print (x3)
print (x3.dtype)

