import numpy as np

a = np.array([[0, 0, 0],
              [5, 5, 5],
              [10, 10, 10],
              [15, 15, 15]])
b = np.array([5, 10, 15])
print(a + b)

