import numpy as np
# 創建一個兩列三行, 未初始化的函數
x = np.empty([2,3], dtype = int)
print (x)

