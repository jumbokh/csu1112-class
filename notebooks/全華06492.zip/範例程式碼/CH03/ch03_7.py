import numpy as np
# 資料型態默認為浮點數
a1 = np.zeros(5)
print(a1)
# 資料型設定為整數
a2 = np.zeros((5,), dtype=np.int)
print(a2)


