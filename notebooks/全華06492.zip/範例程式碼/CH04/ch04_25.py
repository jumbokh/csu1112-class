import tensorflow as tf
i1 = tf.constant([2,0,-3,1])
b1 = tf.cast(i1,tf.bool)
print(b1)