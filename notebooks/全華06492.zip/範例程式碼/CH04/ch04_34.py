import tensorflow as tf

#  根號計算
x = tf.constant([1.,8.,27.])
y = x**(1/3)
print(y)