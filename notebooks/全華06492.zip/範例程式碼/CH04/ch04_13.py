import tensorflow as tf
u1 = tf.random.uniform([2,3],maxval=50,dtype=tf.int32)
print(u1)