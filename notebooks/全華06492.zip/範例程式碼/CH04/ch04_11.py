import tensorflow as tf

n3 = tf.random.normal([2,3],mean=1.0,stddev=2.0)
print(n3)