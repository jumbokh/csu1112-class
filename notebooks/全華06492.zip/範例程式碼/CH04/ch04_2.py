import tensorflow as tf
Degree3 = tf.constant([[[1.2,2.4],[3.6,4.8]],[[2.1,4.2],[6.3,8.4]]])
print(Degree3.ndim)   # 印出 Degree3 張量的階數