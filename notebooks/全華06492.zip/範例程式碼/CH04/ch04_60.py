import tensorflow as tf

Company = tf.random.uniform([2,5,3],maxval=50,dtype=tf.int32)
print(Company)