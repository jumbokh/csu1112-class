import tensorflow as tf

x = tf.math.log(2.)
print(x)

