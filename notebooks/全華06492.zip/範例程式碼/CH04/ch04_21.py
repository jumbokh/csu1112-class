import tensorflow as tf

bool1 = tf.constant(True)
bool2 = tf.constant([True])
bool3 = tf.constant([[True],[False]])
print(bool1)
print(bool2)
print(bool3)