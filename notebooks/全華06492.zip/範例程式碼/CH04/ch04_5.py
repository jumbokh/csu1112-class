import tensorflow as tf

print(tf.constant(12345, dtype= tf.int16))
print(tf.constant(12345, dtype= tf.int32))

print(tf.constant(123456789, dtype= tf.int16))
print(tf.constant(123456789, dtype= tf.int32))