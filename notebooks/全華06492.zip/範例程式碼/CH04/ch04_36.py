import tensorflow as tf

x = tf.exp(1.)  # 自然對數運算
print(x)